http_path = "/"
css_dir = "../"
sass_dir = "scss"
relative_assets = true
preferred_syntax = :scss
#output_style = :compressed #uncomment this for final output